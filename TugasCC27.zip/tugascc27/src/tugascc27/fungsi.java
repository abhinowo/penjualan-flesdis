package tugascc27;
public class fungsi {
    static void identitas(){
        System.out.println("Kelompok 27 Sift 2");
        System.out.println("Nama : Aryo Anindyo A.");
        System.out.println("NIM  : 21120117140020");
        System.out.println("Nama : Okky Nurnanda P");
        System.out.println("NIM  : 21120117130056");
        System.out.println("----------------------");
    }
}
